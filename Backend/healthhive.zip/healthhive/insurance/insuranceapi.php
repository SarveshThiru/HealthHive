<?php
header("Content-Type: application/json");
include '../db.php';

$method = $_SERVER['REQUEST_METHOD'];

// Create Insurance Entry
if ($method === 'POST') {
    if (isset($_POST['user_id'], $_POST['policy_number'], $_POST['insured_name'], $_POST['insurance_provider'], $_POST['plan_type'], $_POST['coverage_amount'], $_POST['premium_amount'], $_POST['policy_start_date'], $_POST['policy_expiry_date'], $_POST['nominee_name'], $_POST['claim_status'], $_POST['last_payment_date'], $_POST['next_renewal_date'])) {

        $coverage_amount = (double) $_POST['coverage_amount'];
        $premium_amount = (double) $_POST['premium_amount'];
        $user_id = (int) $_POST['user_id'];

        $stmt = $conn->prepare("INSERT INTO insurance_details (user_id, policy_number, insured_name, insurance_provider, plan_type, coverage_amount, premium_amount, policy_start_date, policy_expiry_date, nominee_name, claim_status, last_payment_date, next_renewal_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->bind_param("isssssddsssss", 
            $user_id, 
            $_POST['policy_number'], 
            $_POST['insured_name'], 
            $_POST['insurance_provider'], 
            $_POST['plan_type'], 
            $coverage_amount, 
            $premium_amount, 
            $_POST['policy_start_date'], 
            $_POST['policy_expiry_date'], 
            $_POST['nominee_name'], 
            $_POST['claim_status'], 
            $_POST['last_payment_date'], 
            $_POST['next_renewal_date']
        );

        if ($stmt->execute()) {
            echo json_encode(["status" => true, "message" => "Insurance details added successfully", "data" => []]);
        } else {
            echo json_encode(["status" => false, "message" => "Failed to add insurance details", "data" => []]);
        }
        $stmt->close();
    } else {
        echo json_encode(["status" => false, "message" => "Missing required fields", "data" => []]);
    }
}

// Retrieve Insurance by User ID
elseif ($method === 'GET' && isset($_GET['user_id'])) {
    $stmt = $conn->prepare("SELECT * FROM insurance_details WHERE user_id = ?");
    $stmt->bind_param("i", $_GET['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $insurance = [];
    while ($row = $result->fetch_assoc()) {
        $insurance[] = $row;
    }

    echo json_encode([
        "status" => true,
        "message" => count($insurance) > 0 ? "Insurance details retrieved successfully" : "No insurance details found",
        "data" => $insurance
    ]);

    $stmt->close();
}

// Update Insurance Entry
elseif ($method === 'PUT') {
    $data = json_decode(file_get_contents("php://input"), true); 

    if (isset($data['user_id'], $data['policy_number'], $data['insured_name'], $data['insurance_provider'], $data['plan_type'], $data['coverage_amount'], $data['premium_amount'], $data['policy_start_date'], $data['policy_expiry_date'], $data['nominee_name'], $data['claim_status'], $data['last_payment_date'], $data['next_renewal_date'])) {

        $coverage_amount = (double) $data['coverage_amount'];
        $premium_amount = (double) $data['premium_amount'];
        $user_id = (int) $data['user_id'];

        $stmt = $conn->prepare("UPDATE insurance_details SET policy_number=?, insured_name=?, insurance_provider=?, plan_type=?, coverage_amount=?, premium_amount=?, policy_start_date=?, policy_expiry_date=?, nominee_name=?, claim_status=?, last_payment_date=?, next_renewal_date=? WHERE user_id=?");

        $stmt->bind_param("sssssddsssssi", 
            $data['policy_number'], 
            $data['insured_name'], 
            $data['insurance_provider'], 
            $data['plan_type'], 
            $coverage_amount, 
            $premium_amount, 
            $data['policy_start_date'], 
            $data['policy_expiry_date'], 
            $data['nominee_name'], 
            $data['claim_status'], 
            $data['last_payment_date'], 
            $data['next_renewal_date'], 
            $user_id
        );

        if ($stmt->execute()) {
            echo json_encode(["status" => true, "message" => "Insurance details updated successfully", "data" => []]);
        } else {
            echo json_encode(["status" => false, "message" => "Failed to update insurance details", "data" => []]);
        }
        $stmt->close();
    } else {
        echo json_encode(["status" => false, "message" => "Missing required fields", "data" => []]);
    }
}

// Delete Insurance Entry
elseif ($method === 'DELETE') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (isset($data['user_id'])) {
        $stmt = $conn->prepare("DELETE FROM insurance_details WHERE user_id = ?");
        $stmt->bind_param("i", $data['user_id']);

        if ($stmt->execute()) {
            echo json_encode(["status" => true, "message" => "Insurance details deleted successfully", "data" => []]);
        } else {
            echo json_encode(["status" => false, "message" => "Failed to delete insurance details", "data" => []]);
        }
        $stmt->close();
    } else {
        echo json_encode(["status" => false, "message" => "User ID is required", "data" => []]);
    }
}

$conn->close();
?>
