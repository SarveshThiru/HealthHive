<?php
header("Content-Type: application/json; charset=UTF-8");
include '../db.php';

// Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form-data input
    $email = $_POST['email'] ?? '';
    $new_password = $_POST['new_password'] ?? '';

    // Validate input fields
    if (empty($email) || empty($new_password)) {
        echo json_encode(["error" => "Email and new password are required"]);
        exit();
    }

    // Check if user exists
    $sql = "SELECT user_id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        // Hash the new password
        $password_hash = password_hash($new_password, PASSWORD_BCRYPT);
        
        // Update password in the database
        $update_sql = "UPDATE users SET password_hash = ? WHERE email = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ss", $password_hash, $email);

        if ($update_stmt->execute()) {
            echo json_encode(["message" => "Password reset successful"]);
        } else {
            echo json_encode(["error" => "Failed to update password"]);
        }
    } else {
        echo json_encode(["error" => "User not found"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method"]);
}
?>
