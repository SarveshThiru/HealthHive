<?php
header("Content-Type: application/json; charset=UTF-8");
include '../db.php';
require_once __DIR__ . '/../vendor/autoload.php';
use Firebase\JWT\JWT;

$secretKey = 'admin';  // Change this in production

// Function to generate JWT
function generate_jwt($payload) {
    global $secretKey;
    $issuedAt = time();
    $expirationTime = $issuedAt + 3600; // Token valid for 1 hour
    $payload['iat'] = $issuedAt;
    $payload['exp'] = $expirationTime;
    return JWT::encode($payload, $secretKey, 'HS256');
}

// Function to generate unique PID (PIDYYYYXXXXXX)
function generate_pid($conn) {
    $year = date("Y");
    $sql = "SELECT COUNT(user_id) AS count FROM users WHERE YEAR(created_at) = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $year);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['count'] + 1;
    return "PID" . $year . str_pad($count, 6, "0", STR_PAD_LEFT);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $user_id = $_POST['user_id'] ?? '';
    $new_password = $_POST['new_password'] ?? '';

    // **User Registration**
    if (!empty($full_name) && !empty($email) && !empty($password)) {
        $check_email = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
        $check_email->bind_param("s", $email);
        $check_email->execute();
        $result = $check_email->get_result();

        if ($result->num_rows > 0) {
            echo json_encode(["status" => false, "message" => "Email already registered", "data" => []]);
            exit();
        }

        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $pid = generate_pid($conn);
        $sql = "INSERT INTO users (full_name, email, password_hash, pid, created_at) VALUES (?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $full_name, $email, $password_hash, $pid);

        echo json_encode($stmt->execute()
            ? ["status" => true, "message" => "Registration successful", "data" => ["pid" => $pid]]
            : ["status" => false, "message" => "Registration failed", "data" => []]
        );
        exit();
    }

    // **User Login**
    if (!empty($email) && !empty($password) && empty($full_name)) {
        $sql = "SELECT user_id, full_name, password_hash, pid FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password_hash'])) {
                $token = generate_jwt(["user_id" => $row['user_id'], "full_name" => $row['full_name'], "pid" => $row['pid']]);
                echo json_encode(["status" => true, "message" => "Login successful", "data" => ["token" => $token, "pid" => $row['pid']]]);
            } else {
                echo json_encode(["status" => false, "message" => "Invalid password", "data" => []]);
            }
        } else {
            echo json_encode(["status" => false, "message" => "User not found", "data" => []]);
        }
        exit();
    }

    // **Update User**
    if (!empty($user_id) && (!empty($full_name) || !empty($email) || !empty($password))) {
        $check_sql = "SELECT user_id FROM users WHERE user_id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $user_id);
        $check_stmt->execute();
        $result = $check_stmt->get_result();

        if ($result->num_rows === 1) {
            if (!empty($password)) {
                $password_hash = password_hash($password, PASSWORD_BCRYPT);
                $update_sql = "UPDATE users SET full_name = ?, email = ?, password_hash = ? WHERE user_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("sssi", $full_name, $email, $password_hash, $user_id);
            } else {
                $update_sql = "UPDATE users SET full_name = ?, email = ? WHERE user_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("ssi", $full_name, $email, $user_id);
            }

            echo json_encode($update_stmt->execute()
                ? ["status" => true, "message" => "User updated successfully", "data" => []]
                : ["status" => false, "message" => "Failed to update user", "data" => []]
            );
        } else {
            echo json_encode(["status" => false, "message" => "User not found", "data" => []]);
        }
        exit();
    }

    // **Reset Password**
    if (!empty($email) && !empty($new_password)) {
        $sql = "SELECT user_id FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $password_hash = password_hash($new_password, PASSWORD_BCRYPT);
            $update_sql = "UPDATE users SET password_hash = ? WHERE email = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ss", $password_hash, $email);

            echo json_encode($update_stmt->execute()
                ? ["status" => true, "message" => "Password reset successful", "data" => []]
                : ["status" => false, "message" => "Failed to reset password", "data" => []]
            );
        } else {
            echo json_encode(["status" => false, "message" => "User not found", "data" => []]);
        }
        exit();
    }

    echo json_encode(["status" => false, "message" => "Invalid request", "data" => []]);
    exit();
}

// **Invalid Method**
echo json_encode(["status" => false, "message" => "Invalid request method", "data" => []]);
?>
