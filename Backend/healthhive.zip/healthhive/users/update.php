<?php
header("Content-Type: application/json; charset=UTF-8");
include '../db.php';

// Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form-data input
    $user_id = $_POST['user_id'] ?? '';
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validate input
    if (empty($user_id) || empty($full_name) || empty($email)) {
        echo json_encode(["error" => "User ID, full name, and email are required"]);
        exit();
    }

    // Check if user exists
    $check_sql = "SELECT user_id FROM users WHERE user_id = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("i", $user_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows === 1) {
        // Update user details
        if (!empty($password)) {
            // Hash new password if provided
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            $update_sql = "UPDATE users SET full_name = ?, email = ?, password_hash = ? WHERE user_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("sssi", $full_name, $email, $password_hash, $user_id);
        } else {
            $update_sql = "UPDATE users SET full_name = ?, email = ? WHERE user_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ssi", $full_name, $email, $user_id);
        }

        if ($update_stmt->execute()) {
            echo json_encode(["message" => "User updated successfully"]);
        } else {
            echo json_encode(["error" => "Failed to update user"]);
        }
    } else {
        echo json_encode(["error" => "User not found"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method"]);
}
?>
