<?php
header("Content-Type: application/json; charset=UTF-8");
include '../db.php';

// Ensure it's a DELETE request
if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    echo json_encode(["error" => "Invalid request method"]);
    exit();
}

// !!! IMPORTANT: Implement authentication to restrict access to admins only !!!

// Start a transaction
$conn->begin_transaction();

// Delete all users
$sql = "DELETE FROM users";
$stmt = $conn->prepare($sql);

if ($stmt->execute()) {
    $deletedRows = $stmt->affected_rows;
    
    // Reset AUTO_INCREMENT if users were deleted
    if ($deletedRows > 0) {
        $conn->query("ALTER TABLE users AUTO_INCREMENT = 1");
    }
    
    $conn->commit();
    
    if ($deletedRows > 0) {
        echo json_encode(["message" => "All users deleted successfully", "deleted_users" => $deletedRows]);
    } else {
        echo json_encode(["error" => "No users found to delete"]);
    }
} else {
    $conn->rollback();
    echo json_encode(["error" => "Failed to delete users"]);
}

// Close resources
$stmt->close();
$conn->close();
?>
