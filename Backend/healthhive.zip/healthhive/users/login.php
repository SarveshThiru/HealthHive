<?php
include '../db.php';
require_once __DIR__ . '/../vendor/autoload.php';
use Firebase\JWT\JWT;

// Secret key for JWT encoding/decoding
$secretKey = 'admin';  // Replace with a stronger key for production

// Function to generate JWT token
function generate_jwt($payload) {
    global $secretKey;
    $issuedAt = time();
    $expirationTime = $issuedAt + 3600; // Token valid for 1 hour
    $payload['iat'] = $issuedAt;
    $payload['exp'] = $expirationTime;

    return JWT::encode($payload, $secretKey, 'HS256');
}

// Ensure it's a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form-data values
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Check if email and password are provided
    if (empty($email) || empty($password)) {
        echo json_encode(["error" => "Email and password are required"]);
        exit;
    }

    // Prepare and execute the query to check user credentials
    $sql = "SELECT user_id, full_name, password_hash FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $row['password_hash'])) {
            // Generate JWT on successful login
            $token = generate_jwt(["user_id" => $row['user_id'], "full_name" => $row['full_name']]);
            echo json_encode(["message" => "Login successful", "token" => $token]);
        } else {
            echo json_encode(["error" => "Invalid password"]);
        }
    } else {
        echo json_encode(["error" => "User not found"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method"]);
}
?>
