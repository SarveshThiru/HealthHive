<?php
require '../jwt_helper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['token']) || empty($_POST['token'])) {
        echo json_encode(["error" => "Unauthorized - Token missing"]);
        exit();
    }

    $token = $_POST['token'];
    $decoded = validate_jwt($token);

    if (!$decoded) {
        echo json_encode(["error" => "Invalid token"]);
        exit();
    }

    $user_id = $decoded->user_id; // Use this in protected endpoints
    echo json_encode(["message" => "Token verified", "user_id" => $user_id]);
} else {
    echo json_encode(["error" => "Invalid request method"]);
}
?>
