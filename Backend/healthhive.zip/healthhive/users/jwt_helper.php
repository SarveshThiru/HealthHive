<?php
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

$jwt_secret = "admin"; // Replace with a secure key

function generate_jwt($payload) {
    global $jwt_secret;
    return JWT::encode($payload, $jwt_secret, 'HS256');
}

function validate_jwt($token) {
    global $jwt_secret;
    try {
        return JWT::decode($token, new Key($jwt_secret, 'HS256'));
    } catch (Exception $e) {
        return null;
    }
}
?>
