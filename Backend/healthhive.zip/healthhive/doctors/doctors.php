<?php
header("Content-Type: application/json");
require_once '../db.php'; // Database connection

$method = $_SERVER['REQUEST_METHOD'];

// Function to get an existing Doctor ID or generate a new one
function getDoctorID($conn, $name, $specialization) {
    $stmt = $conn->prepare("SELECT doctor_id FROM doctors WHERE name = ? AND specialization = ?");
    $stmt->bind_param("ss", $name, $specialization);
    $stmt->execute();
    $stmt->bind_result($existingDoctorID);
    $stmt->fetch();
    $stmt->close();

    if ($existingDoctorID) {
        return $existingDoctorID;
    }

    do {
        $randomNumber = str_pad(mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);
        $doctor_id = "DID" . $randomNumber;

        $stmt = $conn->prepare("SELECT doctor_id FROM doctors WHERE doctor_id = ?");
        $stmt->bind_param("s", $doctor_id);
        $stmt->execute();
        $stmt->store_result();
    } while ($stmt->num_rows > 0);

    $stmt->close();
    return $doctor_id;
}

// Handle POST request (Add a new doctor)
if ($method === 'POST') {
    if (isset($_POST['user_id'], $_POST['name'], $_POST['specialization'], $_POST['rating'])) {
        $user_id = filter_var($_POST['user_id'], FILTER_VALIDATE_INT);
        $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
        $specialization = filter_var($_POST['specialization'], FILTER_SANITIZE_STRING);
        $rating = filter_var($_POST['rating'], FILTER_VALIDATE_FLOAT);

        if (!$user_id || !$name || !$specialization || $rating === false || $rating < 0 || $rating > 5) {
            echo json_encode(["status" => false, "message" => "Invalid input", "data" => []]);
            exit();
        }

        $doctor_id = getDoctorID($conn, $name, $specialization);

        $stmt = $conn->prepare("INSERT INTO doctors (doctor_id, user_id, name, specialization, rating) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sissd", $doctor_id, $user_id, $name, $specialization, $rating);

        if ($stmt->execute()) {
            echo json_encode(["status" => true, "message" => "Doctor added successfully", "data" => ["doctor_id" => $doctor_id]]);
        } else {
            echo json_encode(["status" => false, "message" => "Failed to add doctor", "data" => []]);
        }
        $stmt->close();
    }
} 
// Handle GET request (Fetch doctor details and consultations)
elseif ($method === 'GET') {
    if (isset($_GET['doctor_id'])) {
        $doctor_id = $_GET['doctor_id'];

        if (!preg_match('/^DID\d{6}$/', $doctor_id)) {
            echo json_encode(["status" => false, "message" => "Invalid doctor_id format", "data" => []]);
            exit();
        }

        // Fetch doctor details
        $stmt = $conn->prepare("SELECT name, specialization, rating FROM doctors WHERE doctor_id = ?");
        $stmt->bind_param("s", $doctor_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            echo json_encode(["status" => true, "message" => "Doctor not found", "data" => []]);
            exit();
        }

        $doctor = $result->fetch_assoc();
        $stmt->close();

        // Fetch consultations related to the doctor
        $stmt = $conn->prepare("SELECT patient_id, patient_name, consultation_date, details FROM consultations WHERE doctor_id = ? ORDER BY consultation_date DESC");
        $stmt->bind_param("s", $doctor_id);
        $stmt->execute();
        $result = $stmt->get_result();

        $consultations = [];
        while ($row = $result->fetch_assoc()) {
            $consultations[] = $row;
        }
        $stmt->close();

        echo json_encode([
            "status" => true,
            "message" => "Doctor and consultation details retrieved",
            "data" => [
                "doctor" => [
                    "doctor_id" => $doctor_id,
                    "name" => $doctor["name"],
                    "specialization" => $doctor["specialization"],
                    "rating" => $doctor["rating"]
                ],
                "consultations" => $consultations
            ]
        ]);
    } else {
        echo json_encode(["status" => false, "message" => "Missing doctor_id", "data" => []]);
    }
}

$conn->close();
?>
