<?php
header("Content-Type: application/json");
require_once '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['name'], $_POST['specialization'], $_POST['rating'])) {
        $stmt = $conn->prepare("INSERT INTO doctors (name, specialization, rating) VALUES (?, ?, ?)");
        $stmt->bind_param("ssd", $_POST['name'], $_POST['specialization'], $_POST['rating']);
        if ($stmt->execute()) {
            echo json_encode(["message" => "Doctor added successfully"]);
        } else {
            echo json_encode(["error" => "Failed to add doctor"]);
        }
        $stmt->close();
    } else {
        echo json_encode(["error" => "Invalid input"]);
    }
}
$conn->close();
?>
