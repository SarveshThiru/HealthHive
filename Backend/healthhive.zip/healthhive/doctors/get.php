<?php
header("Content-Type: application/json");
require_once '../db.php'; // Updated to use ../db.php

$result = $conn->query("SELECT * FROM doctors");
$doctors = [];
while ($row = $result->fetch_assoc()) {
    $doctors[] = $row;
}
echo json_encode($doctors);
$conn->close();
?>
