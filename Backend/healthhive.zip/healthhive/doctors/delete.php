<?php
header("Content-Type: application/json");
require_once '../db.php'; // Updated to use ../db.php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    if (isset($data['doctor_id'])) {
        $stmt = $conn->prepare("DELETE FROM doctors WHERE doctor_id = ?");
        $stmt->bind_param("i", $data['doctor_id']);
        if ($stmt->execute()) {
            echo json_encode(["message" => "Doctor deleted successfully"]);
        } else {
            echo json_encode(["error" => "Failed to delete doctor"]);
        }
        $stmt->close();
    } else {
        echo json_encode(["error" => "Invalid input"]);
    }
}
$conn->close();
?>
