<?php
header("Content-Type: application/json");
require_once '../db.php'; // Use ../db.php for database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['doctor_id']) || !isset($_POST['name']) || !isset($_POST['specialization']) || !isset($_POST['rating'])) {
        echo json_encode(["error" => "Invalid input. Missing required fields."]);
        exit();
    }

    $doctor_id = $_POST['doctor_id'];
    $name = $_POST['name'];
    $specialization = $_POST['specialization'];
    $rating = $_POST['rating'];

    // Validate rating is a decimal number
    if (!is_numeric($rating) || $rating < 0 || $rating > 5) {
        echo json_encode(["error" => "Invalid rating. Must be a number between 0 and 5."]);
        exit();
    }

    $stmt = $conn->prepare("UPDATE doctors SET name = ?, specialization = ?, rating = ? WHERE doctor_id = ?");
    $stmt->bind_param("ssdi", $name, $specialization, $rating, $doctor_id);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Doctor updated successfully"]);
    } else {
        echo json_encode(["error" => "Failed to update doctor"]);
    }

    $stmt->close();
}
$conn->close();
?>
