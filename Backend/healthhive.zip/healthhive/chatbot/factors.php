<?php
header("Content-Type: application/json");

$conn = new mysqli("localhost", "root", "", "healthhive_db");

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed"]));
}

// Capture user input
$user_id = $_POST['user_id'] ?? null;
$query = strtolower($_POST['query'] ?? '');

if (!$user_id || !$query) {
    die(json_encode(["status" => "error", "message" => "Missing user_id or query"]));
}

// Check if user wants health recommendations
if (strpos($query, 'health insights') !== false) {
    // Fetch latest health data from MySQL
    $sql = "SELECT heart_rate, blood_pressure_systolic, blood_pressure_diastolic, blood_sugar, blood_oxygen 
            FROM health_data WHERE user_id = ? ORDER BY recorded_at DESC LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if (!$result) {
        echo json_encode(["status" => "error", "message" => "No recent health data found"]);
        exit;
    }

    // Generate lifestyle-based recommendations
    $recommendations = [];

    if ($result['blood_pressure_systolic'] > 130 || $result['blood_pressure_diastolic'] > 80) {
        $recommendations[] = "Your blood pressure is high. Try a low-sodium diet and stress reduction techniques.";
    }
    if ($result['blood_oxygen'] < 95) {
        $recommendations[] = "Your oxygen level is low. Try deep breathing exercises and ensure proper hydration.";
    }
    if ($result['blood_sugar'] > 140) {
        $recommendations[] = "Your blood sugar level is elevated. Consider reducing sugar intake and exercising regularly.";
    }
    if ($result['heart_rate'] > 100) {
        $recommendations[] = "Your heart rate is high. Try relaxation techniques like meditation or light walking.";
    }

    // Default message if no alerts
    $overall_health = empty($recommendations) ? "Your overall health appears to be stable." : "We detected some areas for improvement.";

    echo json_encode([
        "status" => "success",
        "overall_health" => $overall_health,
        "health_insights" => $recommendations
    ]);
    exit;
}

// Check if user wants reminders
if (strpos($query, 'medication reminder') !== false) {
    $sql = "SELECT name, dosage, frequency, start_date, end_date FROM medications WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $medications = [];
    while ($row = $result->fetch_assoc()) {
        $medications[] = [
            "name" => $row["name"],
            "dosage" => $row["dosage"],
            "frequency" => $row["frequency"],
            "start_date" => $row["start_date"],
            "end_date" => $row["end_date"]
        ];
    }

    if (empty($medications)) {
        echo json_encode(["status" => "error", "message" => "No medications found for reminders"]);
        exit;
    }

    echo json_encode(["status" => "success", "reminders" => $medications]);
    exit;
}

// Default chatbot response
echo json_encode(["status" => "success", "answer" => "I'm here to assist you!"]);
?>
