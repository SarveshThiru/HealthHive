<?php
$conn = new mysqli("localhost", "root", "", "healthhive_db");

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed"]));
}

$user_id = $_POST['user_id'] ?? null;
$message = $_POST['message'] ?? null;
$sender = $_POST['sender'] ?? null;

if (!$user_id || !$message || !$sender) {
    die(json_encode(["status" => "error", "message" => "Missing parameters"]));
}

// Store chat message
$sql = "INSERT INTO chat_history (user_id, message, sender) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iss", $user_id, $message, $sender);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Chat stored"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to store chat"]);
}

$conn->close();
?>
