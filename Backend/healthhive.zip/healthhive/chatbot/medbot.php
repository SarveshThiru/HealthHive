<?php
header("Content-Type: application/json");
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // Database connection
    $conn = new mysqli("localhost", "root", "", "healthhive_db");
    $conn->set_charset("utf8mb4");

    // Validate and sanitize inputs
    $user_id = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
    $query = strtolower(trim($_POST['query'] ?? ''));

    if (!$user_id || empty($query)) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Missing or invalid user_id/query"]);
        exit;
    }

    // Check user query and respond accordingly
    if (strpos($query, 'health insights') !== false) {
        // Fetch latest health data
        $sql = "SELECT heart_rate, blood_pressure_systolic, blood_pressure_diastolic, blood_sugar, blood_oxygen 
                FROM health_data WHERE user_id = ? ORDER BY recorded_at DESC LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();

        if (!$result) {
            echo json_encode(["status" => "error", "message" => "No recent health data found"]);
            exit;
        }

        // Generate health recommendations
        $recommendations = [];
        if ($result['blood_pressure_systolic'] > 130 || $result['blood_pressure_diastolic'] > 80) {
            $recommendations[] = "⚠ High blood pressure detected! Reduce sodium intake & monitor stress levels.";
        }
        if ($result['blood_oxygen'] < 95) {
            $recommendations[] = "⚠ Low oxygen level detected! Try deep breathing exercises and hydration.";
        }
        if ($result['blood_sugar'] > 140) {
            $recommendations[] = "⚠ Elevated blood sugar detected! Reduce sugar intake & maintain regular exercise.";
        }
        if ($result['heart_rate'] > 100) {
            $recommendations[] = "⚠ High heart rate detected! Try meditation or light walking to relax.";
        }

        echo json_encode([
            "status" => "success",
            "overall_health" => empty($recommendations) ? "Your health appears stable." : "We detected some areas for improvement.",
            "health_insights" => $recommendations
        ]);
        exit;
    }

    if (strpos($query, 'medication reminder') !== false) {
        // Fetch medications
        $sql = "SELECT name, dosage, frequency, start_date, end_date 
                FROM medications WHERE user_id = ? ORDER BY start_date DESC LIMIT 50";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        $medications = $result->fetch_all(MYSQLI_ASSOC);
        if (empty($medications)) {
            echo json_encode(["status" => "error", "message" => "No medication reminders found"]);
            exit;
        }

        echo json_encode(["status" => "success", "reminders" => $medications]);
        exit;
    }

    if (strpos($query, 'chat history') !== false) {
        // Fetch chat history
        $sql = "SELECT message, sender, timestamp FROM chat_history WHERE user_id = ? ORDER BY timestamp ASC LIMIT 50";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        $chats = $result->fetch_all(MYSQLI_ASSOC);
        if (empty($chats)) {
            echo json_encode(["status" => "error", "message" => "No chat history found"]);
            exit;
        }

        echo json_encode(["status" => "success", "chats" => $chats]);
        exit;
    }

    // Default chatbot response
    echo json_encode(["status" => "success", "answer" => "I'm here to assist you!"]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Internal server error"]);
    error_log("Chatbot processing error: " . $e->getMessage());
}
?>
