from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    if request.content_type != 'application/json':
        return jsonify({"status": "error", "message": "Invalid Content-Type, must be application/json"}), 415

    data = request.get_json()
    if not data:
        return jsonify({"status": "error", "message": "Invalid JSON data"}), 400

    # Debugging: Log received data
    print("Received Data:", data)

    # Extract health data safely
    try:
        heart_rate = data["heart_rate"]
        bp_systolic = data["blood_pressure_systolic"]
        bp_diastolic = data["blood_pressure_diastolic"]
        blood_sugar = data["blood_sugar"]
        blood_oxygen = data["blood_oxygen"]
    except KeyError as e:
        return jsonify({"status": "error", "message": f"Missing key: {str(e)}"}), 400

    # Individual health assessments
    health_insights = []

    if blood_sugar > 140:
        health_insights.append("High blood sugar detected. Consider monitoring your diet.")
    elif blood_sugar < 70:
        health_insights.append("Low blood sugar detected. You may need a quick energy boost.")

    if bp_systolic > 130 or bp_diastolic > 85:
        health_insights.append("High blood pressure detected. Monitor regularly.")
    elif bp_systolic < 90 or bp_diastolic < 60:
        health_insights.append("Low blood pressure detected. Ensure proper hydration.")

    if heart_rate > 100:
        health_insights.append("Elevated heart rate detected. You may be stressed or overexerted.")
    elif heart_rate < 60:
        health_insights.append("Low heart rate detected. This may be normal if you are athletic.")

    if blood_oxygen < 90:
        health_insights.append("Low oxygen levels detected. Seek medical advice if persistent.")

    # Overall health summary
    if not health_insights:
        overall_health = "Your overall health appears to be stable."
    else:
        overall_health = "There are some concerns in your health data. Please review the insights."

    return jsonify({
        "status": "success",
        "overall_health": overall_health,
        "health_insights": health_insights
    })

if __name__ == "__main__":
    app.run(debug=True)
