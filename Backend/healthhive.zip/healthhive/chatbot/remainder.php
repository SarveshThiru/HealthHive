<?php
header("Content-Type: application/json");
$conn = new mysqli("localhost", "root", "", "healthhive_db");

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed"]));
}

// Capture user_id from form-data request
$user_id = $_POST['user_id'] ?? null;

if (!$user_id) {
    die(json_encode(["status" => "error", "message" => "Missing user_id"]));
}

$sql = "SELECT medication_id, name, dosage, frequency, start_date, end_date, doctor_name, doctor_notes, side_effects, expiry_date, purchase_date FROM medications WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$medications = [];
while ($row = $result->fetch_assoc()) {
    $medications[] = $row;
}

echo json_encode(["status" => "success", "medications" => $medications]);
?>
