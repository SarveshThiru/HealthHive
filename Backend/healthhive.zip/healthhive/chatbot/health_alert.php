<?php
require __DIR__ . '/../vendor/autoload.php';;  // Load PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$conn = new mysqli("localhost", "root", "", "healthhive_db");
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed"]));
}

$user_id = $_POST['user_id'] ?? null;
$query = strtolower($_POST['query'] ?? '');

if (!$user_id || !$query) {
    die(json_encode(["status" => "error", "message" => "Missing user_id or query"]));
}

// Fetch latest health data
$sql = "SELECT heart_rate, blood_pressure_systolic, blood_pressure_diastolic, blood_sugar, blood_oxygen 
        FROM health_data WHERE user_id = ? ORDER BY recorded_at DESC LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result) {
    echo json_encode(["status" => "error", "message" => "No health data found"]);
    exit;
}

// Define critical thresholds
$alerts = [];
if ($result['blood_pressure_systolic'] > 140 || $result['blood_pressure_diastolic'] > 90) {
    $alerts[] = "⚠ High blood pressure detected! Reduce sodium intake & monitor stress levels.";
}
if ($result['blood_oxygen'] < 90) {
    $alerts[] = "⚠ Low oxygen level detected! Try deep breathing exercises and hydration.";
}
if ($result['blood_sugar'] > 200) {
    $alerts[] = "⚠ High blood sugar detected! Monitor carbohydrate intake and stay active.";
}
if ($result['heart_rate'] < 50 || $result['heart_rate'] > 120) {
    $alerts[] = "⚠ Abnormal heart rate detected! Consult a doctor if symptoms persist.";
}

// Fetch user email
$sql = "SELECT email FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!empty($alerts)) {
    // Send Email alert
    sendEmailAlert($user['email'], implode("<br>", $alerts));
    echo json_encode(["status" => "alert", "alerts" => $alerts, "message" => "Emergency email notification sent!"]);
} else {
    echo json_encode(["status" => "success", "message" => "No critical health issues detected."]);
}

// Function to send email alert
function sendEmailAlert($email, $message) {
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'your-email@gmail.com';
        $mail->Password = 'your-email-password';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('your-email@gmail.com', 'HealthHive Alerts');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = '🚨 HealthHive Emergency Alert!';
        $mail->Body    = "<h3>Urgent Health Alert!</h3><p>{$message}</p>";

        $mail->send();
    } catch (Exception $e) {
        error_log("Email failed: " . $mail->ErrorInfo);
    }
}
?>
