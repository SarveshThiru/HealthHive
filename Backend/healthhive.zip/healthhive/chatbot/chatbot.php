<?php
// Required libraries
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../vendor/autoload.php';
require '../vendor/tecnickcom/tcpdf/tcpdf.php';

// Database connection
$conn = new mysqli("localhost", "root", "", "healthhive_db");
if ($conn->connect_error) {
    die(json_encode(["status" => false, "message" => "Database connection failed", "data" => []]));
}

header("Content-Type: application/json");

// Capture and sanitize user input
$user_id = filter_var($_POST['user_id'] ?? null, FILTER_VALIDATE_INT);
$query = strtolower(trim(htmlspecialchars($_POST['query'] ?? '')));

if (!$user_id || !$query) {
    echo json_encode(["status" => false, "message" => "Missing user_id or query", "data" => []]);
    exit;
}

// Function to store chat messages
function storeChat($conn, $user_id, $message, $sender) {
    $stmt = $conn->prepare("INSERT INTO chat_history (user_id, message, sender, timestamp) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $user_id, $message, $sender);
    $stmt->execute();
    $stmt->close();
}

// Store user query in chat history
storeChat($conn, $user_id, $query, "user");

// Check for health insights request
if (preg_match("/(health insights|health status|my health)/i", $query)) {
    handleHealthInsights($conn, $user_id);
    exit;
}

// If general question, use AI response
$bot_response = getMistralResponse($query);
storeChat($conn, $user_id, $bot_response, "bot");

echo json_encode(["status" => true, "message" => "Response generated successfully", "data" => ["answer" => $bot_response]]);
exit;

/**
 * Handle health insights request
 */
function handleHealthInsights($conn, $user_id) {
    $sql = "SELECT u.full_name, h.health_id, u.email, 
                   h.heart_rate, h.blood_pressure_systolic, h.blood_pressure_diastolic, 
                   h.blood_sugar, h.blood_oxygen, h.recorded_at
            FROM users u
            LEFT JOIN health_data h ON u.user_id = h.user_id
            WHERE u.user_id = ?
            ORDER BY h.recorded_at DESC LIMIT 1";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if (!$result) {
        $response = ["status" => false, "message" => "No recent health data found", "data" => []];
        storeChat($conn, $user_id, json_encode($response), "bot");
        echo json_encode($response);
        return;
    }

    // Extract health data
    $full_name = $result['full_name'];
    $health_id = $result['health_id'];
    $email = $result['email'];
    $heart_rate = $result['heart_rate'];
    $bp_systolic = $result['blood_pressure_systolic'];
    $bp_diastolic = $result['blood_pressure_diastolic'];
    $blood_sugar = $result['blood_sugar'];
    $blood_oxygen = $result['blood_oxygen'];
    $recorded_at = $result['recorded_at'];

    // Generate recommendations
    $recommendations = [];
    if ($bp_systolic > 130 || $bp_diastolic > 80) {
        $recommendations[] = "High blood pressure detected. Consider a low-sodium diet and stress reduction.";
    }
    if ($blood_oxygen < 95) {
        $recommendations[] = "Low blood oxygen level. Try deep breathing exercises and hydration.";
    }
    if ($blood_sugar > 140) {
        $recommendations[] = "High blood sugar detected. Reduce sugar intake and increase physical activity.";
    }
    if ($heart_rate > 100) {
        $recommendations[] = "High heart rate. Try relaxation techniques like meditation or light exercise.";
    }

    $overall_health = empty($recommendations) ? "Your health looks stable!" : "🚨 Some health concerns detected.";

    $response = [
        "status" => true,
        "message" => "Health insights retrieved",
        "data" => [
            "overall_health" => $overall_health,
            "health_insights" => $recommendations
        ]
    ];

    storeChat($conn, $user_id, json_encode($response), "bot");

    if (!empty($recommendations)) {
        sendEmailAlert($full_name, $health_id, $email, $heart_rate, $bp_systolic, $bp_diastolic, $blood_sugar, $blood_oxygen, $recorded_at, $recommendations);
    }

    echo json_encode($response);
}

/**
 * Generate health report PDF
 */
function generateHealthReportPDF($full_name, $health_id, $heart_rate, $bp_systolic, $bp_diastolic, $blood_sugar, $blood_oxygen, $recorded_at, $issues) {
    $pdf = new TCPDF();
    $pdf->SetMargins(10, 10, 10);
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);

    // Title
    $pdf->Cell(0, 10, "Health Report - HealthHive", 0, 1, 'C');

    // Patient details
    $pdf->MultiCell(0, 8, "Patient Name: $full_name\nHealth ID: $health_id\nDate: $recorded_at", 0, 'L');

    // Health data
    $pdf->MultiCell(0, 6, " Heart Rate: $heart_rate bpm\n Blood Pressure: $bp_systolic/$bp_diastolic mmHg\n Blood Sugar: $blood_sugar mg/dL\n Blood Oxygen: $blood_oxygen%", 0, 'L');

    // Save PDF
    $filePath = __DIR__ . "/health_report_$health_id.pdf";
    $pdf->Output($filePath, 'F');
    return $filePath;
}

/**
 * Send email alert
 */
function sendEmailAlert($full_name, $health_id, $email, $heart_rate, $bp_systolic, $bp_diastolic, $blood_sugar, $blood_oxygen, $recorded_at, $issues) {
    $pdfFilePath = generateHealthReportPDF($full_name, $health_id, $heart_rate, $bp_systolic, $bp_diastolic, $blood_sugar, $blood_oxygen, $recorded_at, $issues);

    $subject = "HealthHive Alert: Abnormal Health Insights Detected";
    $message = "<h3>Dear $full_name,</h3><p>We detected some health concerns. Please find the attached report.</p><p>Stay Safe,<br>HealthHive Team</p>";

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'healthhivewellbeing@gmail.com';
        $mail->Password = 'woyx qxqn vprx';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('no-reply@healthhive.com', 'HealthHive Alerts');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;
        $mail->addAttachment($pdfFilePath);
        $mail->send();
        unlink($pdfFilePath);
    } catch (Exception $e) {
        error_log("Email could not be sent. Mailer Error: {$mail->ErrorInfo}");
    }
}

/**
 * Get AI chatbot response
 */
function getMistralResponse($query) {
    $url = "http://localhost:11434/api/generate";
    $postData = json_encode(["model" => "mistral", "prompt" => $query, "stream" => false]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true)["response"] ?? "I couldn't generate a response.";
}
?>
