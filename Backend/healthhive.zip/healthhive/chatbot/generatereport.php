<?php
require_once('../TCPDF-6.8.2/tcpdf.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../vendor/autoload.php';

// Database connection
$servername = "localhost";
$username = "root"; 
$password = "";  
$dbname = "healthhive_db"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "DB connection failed"]));
}

// Read user_id from POST request
$input = json_decode(file_get_contents("php://input"), true);
if (!isset($input['user_id'])) {
    die(json_encode(["status" => "error", "message" => "Missing user_id"]));
}

$user_id = intval($input['user_id']);

// Fetch user details
$sql_user = "SELECT user_id, PID, full_name, email FROM users WHERE user_id = $user_id";
$result_user = $conn->query($sql_user);
if ($result_user->num_rows == 0) {
    die(json_encode(["status" => "error", "message" => "User not found"]));
}
$userData = $result_user->fetch_assoc();

// Fetch health data
$sql_health = "SELECT heart_rate, blood_pressure_systolic, blood_pressure_diastolic, blood_sugar, blood_oxygen, recorded_at FROM health_data WHERE user_id = $user_id ORDER BY recorded_at DESC LIMIT 1";
$result_health = $conn->query($sql_health);
$healthData = $result_health->fetch_assoc() ?? null;

// Fetch doctor info
$sql_doctor = "SELECT name, specialization FROM doctors LIMIT 1";
$result_doctor = $conn->query($sql_doctor);
$doctorInfo = $result_doctor->fetch_assoc() ?? null;
$conn->close();

// Generate PDF
$pdf = new TCPDF();
$pdf->SetCreator('HealthHive');
$pdf->SetTitle('Health Report');
$pdf->AddPage();

// Add Logo
$logoPath = '../assets/logo.png';
if (file_exists($logoPath)) {
    $pdf->Image($logoPath, 160, 10, 30);
}

// User Info
$pdf->SetFont('helvetica', 'B', 12);
$pdf->Cell(0, 10, "Health Report", 0, 1, 'C');
$pdf->SetFont('helvetica', '', 11);
$pdf->Cell(0, 8, "Name: " . $userData['full_name'], 0, 1);
$pdf->Cell(0, 8, "User ID: " . $userData['user_id'], 0, 1);
$pdf->Cell(0, 8, "PID: " . $userData['PID'], 0, 1);
$pdf->Ln(5);

// Health Data Section
if ($healthData) {
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, "Recent Health Data", 0, 1, 'L');
    $pdf->SetFont('helvetica', '', 11);
    $pdf->Cell(0, 8, "Heart Rate: " . ($healthData['heart_rate'] ?? "N/A") . " bpm", 0, 1);
    $pdf->Cell(0, 8, "Blood Pressure: " . ($healthData['blood_pressure_systolic'] ?? "N/A") . "/" . ($healthData['blood_pressure_diastolic'] ?? "N/A") . " mmHg", 0, 1);
    $pdf->Cell(0, 8, "Blood Sugar: " . ($healthData['blood_sugar'] ?? "N/A") . " mg/dL", 0, 1);
    $pdf->Cell(0, 8, "Blood Oxygen: " . ($healthData['blood_oxygen'] ?? "N/A") . " %", 0, 1);
    $pdf->Cell(0, 8, "Recorded At: " . ($healthData['recorded_at'] ?? "N/A"), 0, 1);
    $pdf->Ln(5);
} else {
    $pdf->SetFont('helvetica', 'I', 11);
    $pdf->Cell(0, 8, "No recent health data available.", 0, 1);
}

// Doctor Signature
$pdf->Ln(10);
$pdf->SetFont('helvetica', 'B', 11);
$pdf->Cell(0, 8, $doctorInfo['name'] ?? "Dr. John Doe", 0, 1, 'L');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(0, 8, "Specialization: " . ($doctorInfo['specialization'] ?? "General Practitioner"), 0, 1, 'L');

// Save PDF
$pdfFilePath = __DIR__ . "/Health_report_" . $userData['PID'] . ".pdf";
$pdf->Output($pdfFilePath, 'F');

// Send Email
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'healthhivewellbeing@gmail.com';
    $mail->Password = 'woyx qxqn vprx mfii';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('noreply@healthhive.com', 'HealthHive Reports');
    $mail->addAddress($userData['email']);
    $mail->Subject = "Your Health Report";
    $mail->Body = "Please find attached your health report.";
    $mail->addAttachment($pdfFilePath);

    $mail->send();
    echo json_encode(["status" => "success", "message" => "Report sent to " . $userData['email']]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "Email sending failed: " . $mail->ErrorInfo]);
}
?>
