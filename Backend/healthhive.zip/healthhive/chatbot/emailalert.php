<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/autoload.php'; // Include PHPMailer
require '../db.php'; // Include your database connection file

// Get JSON input
$data = json_decode(file_get_contents("php://input"), true);
$email = isset($data['email']) ? $data['email'] : '';
$user_id = isset($data['user_id']) ? (int)$data['user_id'] : 0;

if (empty($email) || empty($user_id)) {
    echo json_encode(["status" => "error", "message" => "Email and User ID are required"]);
    exit;
}

// Fetch the latest health data
$stmt = $conn->prepare("SELECT heart_rate, blood_pressure_systolic, blood_pressure_diastolic, blood_sugar, blood_oxygen 
                        FROM health_data WHERE user_id = ? ORDER BY recorded_at DESC LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result) {
    echo json_encode(["status" => "error", "message" => "No recent health data found"]);
    exit;
}

// Generate health insights
$issues = [];
if ($result['blood_pressure_systolic'] > 130 || $result['blood_pressure_diastolic'] > 80) {
    $issues[] = "⚠ High Blood Pressure - Reduce sodium intake and manage stress.";
}
if ($result['blood_oxygen'] < 95) {
    $issues[] = "⚠ Low Oxygen Level - Practice deep breathing exercises.";
}
if ($result['blood_sugar'] > 140) {
    $issues[] = "⚠ High Blood Sugar - Monitor diet and exercise regularly.";
}
if ($result['heart_rate'] > 100) {
    $issues[] = "⚠ Elevated Heart Rate - Consider relaxation techniques.";
}

if (empty($issues)) {
    echo json_encode(["status" => "success", "message" => "No health alerts. You are stable!"]);
    exit;
}

// Prepare the email content
$subject = "HealthHive Alert: Abnormal Health Insights Detected";
$message = "<h3>Dear User,</h3><p>We detected some abnormalities in your health data:</p><ul>";
foreach ($issues as $issue) {
    $message .= "<li>$issue</li>";
}
$message .= "</ul><p>Please take precautions and consult a doctor if necessary.</p>
            <p>Stay Safe,<br>HealthHive Team</p>";

// Send Email
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'healthhivewellbeing@gmail.com'; // Your SMTP email
    $mail->Password = 'woyx qxqn vprx mfii'; // Use Gmail App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('no-reply@healthhive.com', 'HealthHive Alerts');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $message;
    
    $mail->send();
    echo json_encode(["status" => "success", "message" => "Health alert sent successfully"]);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => "Mailer Error: " . $mail->ErrorInfo]);
}
?>