<?php
header("Content-Type: application/json"); // Ensure proper JSON response
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT); // Enable error reporting

$conn = new mysqli("localhost", "root", "", "healthhive_db");

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

if ($user_id <= 0) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid or missing user_id"]);
    exit;
}

// Prepare SQL statement
$sql = "SELECT message, sender, timestamp FROM chat_history WHERE user_id = ? ORDER BY timestamp ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$chats = [];
while ($row = $result->fetch_assoc()) {
    $chats[] = $row;
}

// Close connections
$stmt->close();
$conn->close();

// Send response
echo json_encode(["status" => "success", "chats" => $chats], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
