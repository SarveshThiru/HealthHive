<?php
require 'vendor/autoload.php';

use Firebase\JWT\JWT;

$key = "admin";
$payload = ["user_id" => 123, "role" => "admin"];

$jwt = JWT::encode($payload, $key, 'HS256');

echo "Generated JWT: " . $jwt;
