<?php

header('Content-Type: application/json'); // Ensure JSON response format

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["user_id"])) {
        $user_id = $_POST["user_id"];

        // Establish the database connection
        require("../db.php");

        // Check connection
        if ($conn->connect_error) {
            echo json_encode(["status" => "failure", "message" => "Connection failed: " . $conn->connect_error]);
            exit();
        }

        // Query to retrieve the oxygen level values for the given user_id
        $sql = "SELECT blood_oxygen
                FROM health_data
                WHERE user_id = '$user_id'
                ORDER BY recorded_at DESC";

        $result = $conn->query($sql);

        if (!$result) {
            echo json_encode(["status" => "failure", "message" => "Query failed: " . $conn->error]);
            exit();
        }

        if ($result->num_rows > 0) {
            // Fetch all oxygen level values into an array
            $blood_oxygens = array();
            while ($row = $result->fetch_assoc()) {
                $blood_oxygens[] = ["blood_oxygen" => $row['blood_oxygen']];
            }

            // Prepare the success response
            echo json_encode(["status" => "success", "data" => $blood_oxygens]);
        } else {
            // No records found
            echo json_encode(["status" => "failure", "message" => "No oxygen level data found for the given user ID"]);
        }

        // Close the database connection
        $conn->close();
    } else {
        echo json_encode(["status" => "failure", "message" => "User ID not provided"]);
    }
}
