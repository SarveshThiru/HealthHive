<?php
header("Content-Type: application/json");
include '../db.php'; // Centralized database connection

// Function to delete health data by health_id
function deleteHealthData($conn, $healthId) {
    $sql = "DELETE FROM health_data WHERE health_id = ?"; // Ensure health_id is VARCHAR(12)
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $healthId); // Change to "s" for VARCHAR type
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo json_encode(["message" => "Health data deleted from HealthHive"]);
    } else {
        echo json_encode(["error" => "Health data not found for the given health_id"]);
    }

    $stmt->close();
}

// Allow DELETE or POST request
$method = $_SERVER['REQUEST_METHOD'];
if ($method === 'DELETE' || $method === 'POST') { 
    // Retrieve health_id from either DELETE request body or POST request
    $healthId = $_POST['health_id'] ?? file_get_contents("php://input");

    if ($healthId) {
        deleteHealthData($conn, trim($healthId)); // Trim to avoid spaces or unwanted characters
    } else {
        echo json_encode(["error" => "Missing health_id"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method. Use DELETE or POST to remove health data."]);
}

$conn->close();
?>
