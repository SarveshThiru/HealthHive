<?php
header("Content-Type: application/json");
include '../db.php';

// Function to generate a unique Health ID for each user
function generateHealthID($conn, $userId) {
    $healthId = "HMID" . str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
    
    // Ensure uniqueness in DB
    $stmt = $conn->prepare("SELECT health_id FROM health_data WHERE health_id = ?");
    $stmt->bind_param("s", $healthId);
    $stmt->execute();
    $stmt->store_result();

    while ($stmt->num_rows > 0) {
        $healthId = "HMID" . str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
        $stmt->bind_param("s", $healthId);
        $stmt->execute();
        $stmt->store_result();
    }

    $stmt->close();
    return $healthId;
}

// Function to add health data (allows multiple entries per user per day)
function addHealthData($conn, $userId, $heartRate, $bloodPressureSystolic, $bloodPressureDiastolic, $bloodSugar, $bloodOxygen) {
    // Check if user has an existing health_id
    $sql = "SELECT health_id FROM health_data WHERE user_id = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        // Use existing health_id for user
        $stmt->bind_result($healthId);
        $stmt->fetch();
    } else {
        // Generate new health_id if user has no previous entries
        $healthId = generateHealthID($conn, $userId);
    }
    $stmt->close();

    // Insert new record (allows multiple entries with the same health_id)
    $insertSQL = "INSERT INTO health_data (health_id, user_id, heart_rate, blood_pressure_systolic, blood_pressure_diastolic, blood_sugar, blood_oxygen, recorded_at) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
    $insertStmt = $conn->prepare($insertSQL);
    $insertStmt->bind_param("siiiidd", $healthId, $userId, $heartRate, $bloodPressureSystolic, $bloodPressureDiastolic, $bloodSugar, $bloodOxygen);

    if ($insertStmt->execute()) {
        echo json_encode(["message" => "Health data recorded", "health_id" => $healthId]);
    } else {
        echo json_encode(["error" => "Failed to add health data"]);
    }
    $insertStmt->close();
}

// Ensure request is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_POST['user_id'] ?? null;
    $heartRate = $_POST['heart_rate'] ?? null;
    $bloodPressureSystolic = $_POST['blood_pressure_systolic'] ?? null;
    $bloodPressureDiastolic = $_POST['blood_pressure_diastolic'] ?? null;
    $bloodSugar = $_POST['blood_sugar'] ?? null;
    $bloodOxygen = $_POST['blood_oxygen'] ?? null;

    // Validate input
    if ($userId && $heartRate && $bloodPressureSystolic && $bloodPressureDiastolic && $bloodSugar && $bloodOxygen) {
        addHealthData($conn, $userId, $heartRate, $bloodPressureSystolic, $bloodPressureDiastolic, $bloodSugar, $bloodOxygen);
    } else {
        echo json_encode(["error" => "Missing required fields. Please provide all health data fields."]);
    }
} else {
    echo json_encode(["error" => "Invalid request method. Use POST to add health data."]);
}

$conn->close();
?>
