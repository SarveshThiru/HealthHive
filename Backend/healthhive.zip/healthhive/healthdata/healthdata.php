<?php
header("Content-Type: application/json");
include '../db.php'; // Database connection

// Enable MySQLi strict mode for better error handling
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Function to get or generate a unique Health ID for a user
function getOrCreateHealthID($conn, $userId) {
    $stmt = $conn->prepare("SELECT health_id FROM health_data WHERE user_id = ? LIMIT 1");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($existingHealthId);
    $stmt->fetch();
    $stmt->close();

    if ($existingHealthId) {
        return $existingHealthId;
    }

    do {
        $healthId = "HMID" . str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
        $stmt = $conn->prepare("SELECT health_id FROM health_data WHERE health_id = ?");
        $stmt->bind_param("s", $healthId);
        $stmt->execute();
        $stmt->store_result();
    } while ($stmt->num_rows > 0);
    $stmt->close();

    return $healthId;
}

// Function to add health data
function addHealthData($conn, $userId, $heartRate, $bloodPressureSystolic, $bloodPressureDiastolic, $bloodSugar, $bloodOxygen) {
    $healthId = getOrCreateHealthID($conn, $userId);

    $sql = "INSERT INTO health_data (health_id, user_id, heart_rate, blood_pressure_systolic, blood_pressure_diastolic, blood_sugar, blood_oxygen, recorded_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siiiidd", $healthId, $userId, $heartRate, $bloodPressureSystolic, $bloodPressureDiastolic, $bloodSugar, $bloodOxygen);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(["status" => true, "message" => "Health data recorded", "data" => ["health_id" => $healthId]]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => false, "message" => "Failed to add health data", "data" => null]);
    }
    $stmt->close();
}

// Function to fetch health data
function fetchHealthData($conn, $userId) {
    $sql = "SELECT health_id, heart_rate, blood_pressure_systolic, blood_pressure_diastolic, blood_sugar, blood_oxygen, recorded_at 
            FROM health_data 
            WHERE user_id = ? 
            ORDER BY recorded_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $data = $result->fetch_all(MYSQLI_ASSOC);

    http_response_code(200);
    echo json_encode(["status" => true, "message" => "Health data retrieved", "data" => $data]);
    $stmt->close();
}

// Function to delete health data
function deleteHealthData($conn, $healthId) {
    $sql = "DELETE FROM health_data WHERE health_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $healthId);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        http_response_code(200);
        echo json_encode(["status" => true, "message" => "Health data deleted", "data" => null]);
    } else {
        http_response_code(404);
        echo json_encode(["status" => false, "message" => "Health data not found", "data" => null]);
    }
    $stmt->close();
}

// Handle request type
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $healthId = $_POST['health_id'] ?? null;

    if ($healthId) {
        if (preg_match('/^HMID\d{6}$/', trim($healthId))) {
            deleteHealthData($conn, trim($healthId));
        } else {
            http_response_code(400);
            echo json_encode(["status" => false, "message" => "Invalid health_id", "data" => null]);
        }
    } else {
        $userId = $_POST['user_id'] ?? null;
        $heartRate = $_POST['heart_rate'] ?? null;
        $bloodPressureSystolic = $_POST['blood_pressure_systolic'] ?? null;
        $bloodPressureDiastolic = $_POST['blood_pressure_diastolic'] ?? null;
        $bloodSugar = $_POST['blood_sugar'] ?? null;
        $bloodOxygen = $_POST['blood_oxygen'] ?? null;

        if ($userId && $heartRate && $bloodPressureSystolic && $bloodPressureDiastolic && $bloodSugar && $bloodOxygen) {
            addHealthData($conn, $userId, $heartRate, $bloodPressureSystolic, $bloodPressureDiastolic, $bloodSugar, $bloodOxygen);
        } else {
            http_response_code(400);
            echo json_encode(["status" => false, "message" => "Missing required fields", "data" => null]);
        }
    }
} elseif ($method === 'GET') {
    $userId = $_GET['user_id'] ?? null;

    if ($userId) {
        fetchHealthData($conn, $userId);
    } else {
        http_response_code(400);
        echo json_encode(["status" => false, "message" => "Missing user_id", "data" => null]);
    }
} else {
    http_response_code(405);
    echo json_encode(["status" => false, "message" => "Invalid request method. Use GET, POST", "data" => null]);
}

$conn->close();
?>
