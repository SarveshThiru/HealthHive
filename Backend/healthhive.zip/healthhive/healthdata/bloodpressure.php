<?php

header('Content-Type: application/json'); // Ensure JSON response format

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["user_id"])) {
        $user_id = $_POST["user_id"];

        // Establish the database connection
        require("../db.php");

        // Check connection
        if ($conn->connect_error) {
            echo json_encode(["status" => "failure", "message" => "Connection failed: " . $conn->connect_error]);
            exit();
        }

        // Query to retrieve the blood pressure values for the given user_id
        $sql = "SELECT blood_pressure_systolic, blood_pressure_diastolic
                FROM health_data
                WHERE user_id = '$user_id'
                ORDER BY recorded_at DESC";

        $result = $conn->query($sql);

        if (!$result) {
            echo json_encode(["status" => "failure", "message" => "Query failed: " . $conn->error]);
            exit();
        }

        if ($result->num_rows > 0) {
            // Fetch all blood pressure values into an array
            $blood_pressure_values = array();
            while ($row = $result->fetch_assoc()) {
                $blood_pressure_values[] = [
                    "blood_pressure_systolic" => $row['blood_pressure_systolic'],
                    "blood_pressure_diastolic" => $row['blood_pressure_diastolic']
                ];
            }

            // Prepare the success response
            echo json_encode(["status" => "success", "data" => $blood_pressure_values]);
        } else {
            // No records found
            echo json_encode(["status" => "failure", "message" => "No blood pressure data found for the given user ID"]);
        }

        // Close the database connection
        $conn->close();
    } else {
        echo json_encode(["status" => "failure", "message" => "User ID not provided"]);
    }
}
