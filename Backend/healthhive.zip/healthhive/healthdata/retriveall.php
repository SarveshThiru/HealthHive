<?php
header("Content-Type: application/json");
include '../db.php';

// Ensure request is GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $userId = filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT);

    if ($userId) {
        $sql = "SELECT health_id, heart_rate, blood_pressure_systolic, blood_pressure_diastolic, blood_sugar, blood_oxygen, recorded_at 
                FROM health_data 
                WHERE user_id = ? 
                ORDER BY health_id DESC, recorded_at DESC";
                
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        
        echo json_encode(["health_data" => $data]);
        $stmt->close();
    } else {
        echo json_encode(["error" => "Invalid or missing user_id"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method. Use GET to fetch health data."]);
}

$conn->close();
?>
