<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Decode the JSON data
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (isset($_POST["user_id"])) {
        $user_id = $_POST["user_id"];

        // Establish the database connection
        require("../db.php");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to retrieve the blood sugar values for the given user_id
        $sql = "SELECT blood_sugar
                FROM health_data
                WHERE user_id = '$user_id'
                ORDER BY recorded_at DESC"; // Order by record_date in descending order
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch all blood sugar values into an array
            $blood_sugar_values = array();
            while ($row = $result->fetch_assoc()) {
                $blood_sugar_values[] = $row['blood_sugar'];
            }

            // Prepare the response
            $response = $blood_sugar_values;
        } else {
            // No records found
            $response['status'] = 'failure';
            $response['message'] = 'No blood sugar data found for the given user ID';
        }

        // Close the database connection
        $conn->close();
    } else {
        $response['status'] = 'failure';
        $response['message'] = 'User ID not provided';
    }

    // Send the JSON-encoded response
    echo json_encode($response);
}