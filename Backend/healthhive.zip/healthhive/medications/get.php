<?php
header("Content-Type: application/json");
include '../db.php'; // Include database connection

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate if user_id is provided
    if (!empty($_POST['user_id'])) {
        // Get the user ID from form-data
        $userId = intval($_POST['user_id']);

        // Prepare SQL statement
        $sql = "SELECT * FROM medications WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        // Fetch all medication records
        $medications = [];
        while ($row = $result->fetch_assoc()) {
            $medications[] = $row;
        }

        // Return JSON response
        echo json_encode($medications);

        $stmt->close();
    } else {
        echo json_encode(["error" => "User ID is required"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method. Use POST to fetch medications."]);
}

$conn->close();
?>
