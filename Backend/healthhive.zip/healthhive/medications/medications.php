<?php
header("Content-Type: application/json");
include '../db.php'; // Include database connection

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {  // Add Medication
    if (!empty($_POST['user_id']) && !empty($_POST['name']) && !empty($_POST['dosage']) && 
        !empty($_POST['frequency']) && !empty($_POST['start_date'])) {

        $userId = intval($_POST['user_id']);
        $name = $_POST['name'];
        $dosage = $_POST['dosage'];
        $frequency = $_POST['frequency'];
        $startDate = $_POST['start_date'];
        $endDate = $_POST['end_date'] ?? null;
        $doctorName = $_POST['doctor_name'] ?? null;
        $doctorNotes = $_POST['doctor_notes'] ?? null;
        $sideEffects = $_POST['side_effects'] ?? null;
        $expiryDate = $_POST['expiry_date'] ?? null;
        $purchaseDate = $_POST['purchase_date'] ?? null;

        $stmt = $conn->prepare("INSERT INTO medications 
            (user_id, name, dosage, frequency, start_date, end_date, doctor_name, doctor_notes, side_effects, expiry_date, purchase_date) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->bind_param("issssssssss", $userId, $name, $dosage, $frequency, $startDate, $endDate, $doctorName, $doctorNotes, $sideEffects, $expiryDate, $purchaseDate);

        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(["status" => true, "message" => "Medication added successfully", "data" => []]);
        } else {
            http_response_code(500);
            echo json_encode(["status" => false, "message" => "Failed to add medication", "data" => []]);
        }

        $stmt->close();
    } else {
        http_response_code(200);
        echo json_encode(["status" => false, "message" => "Missing required fields", "data" => []]);
    }

} elseif ($method === 'GET') {  // Fetch Medications
    if (!empty($_GET['user_id'])) {
        $userId = intval($_GET['user_id']);
        $stmt = $conn->prepare("SELECT * FROM medications WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $medications = [];

        while ($row = $result->fetch_assoc()) {
            $medications[] = $row;
        }

        http_response_code(200);
        echo json_encode(["status" => true, "message" => count($medications) ? "Medications fetched successfully" : "No medications found", "data" => $medications]);

        $stmt->close();
    } else {
        http_response_code(200);
        echo json_encode(["status" => false, "message" => "User ID is required", "data" => []]);
    }

} elseif ($method === 'PUT') {  // Update Medication
    parse_str(file_get_contents("php://input"), $_PUT);
    
    if (!empty($_PUT['medication_id'])) {
        $medicationId = intval($_PUT['medication_id']);
        $name = $_PUT['name'] ?? null;
        $dosage = $_PUT['dosage'] ?? null;
        $frequency = $_PUT['frequency'] ?? null;
        $startDate = $_PUT['start_date'] ?? null;
        $endDate = $_PUT['end_date'] ?? null;
        $doctorName = $_PUT['doctor_name'] ?? null;
        $doctorNotes = $_PUT['doctor_notes'] ?? null;
        $sideEffects = $_PUT['side_effects'] ?? null;
        $expiryDate = $_PUT['expiry_date'] ?? null;
        $purchaseDate = $_PUT['purchase_date'] ?? null;

        $checkSql = "SELECT 1 FROM medications WHERE medication_id = ?";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->bind_param("i", $medicationId);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows === 0) {
            http_response_code(200);
            echo json_encode(["status" => false, "message" => "Medication not found", "data" => []]);
            exit;
        }
        $checkStmt->close();

        $sql = "UPDATE medications 
                SET name=?, dosage=?, frequency=?, start_date=?, end_date=?, doctor_name=?, doctor_notes=?, side_effects=?, expiry_date=?, purchase_date=? 
                WHERE medication_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssi", $name, $dosage, $frequency, $startDate, $endDate, $doctorName, $doctorNotes, $sideEffects, $expiryDate, $purchaseDate, $medicationId);

        if ($stmt->execute() && $stmt->affected_rows > 0) {
            http_response_code(200);
            echo json_encode(["status" => true, "message" => "Medication updated successfully", "data" => []]);
        } else {
            http_response_code(500);
            echo json_encode(["status" => false, "message" => "Failed to update medication or no changes made", "data" => []]);
        }

        $stmt->close();
    } else {
        http_response_code(200);
        echo json_encode(["status" => false, "message" => "Medication ID is required", "data" => []]);
    }

} elseif ($method === 'DELETE') {  // Delete Medication
    parse_str(file_get_contents("php://input"), $_DELETE);
    
    if (!empty($_DELETE['medication_id'])) {
        $medicationId = intval($_DELETE['medication_id']);

        $checkSql = "SELECT 1 FROM medications WHERE medication_id = ?";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->bind_param("i", $medicationId);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows === 0) {
            http_response_code(200);
            echo json_encode(["status" => false, "message" => "Medication not found", "data" => []]);
            exit;
        }
        $checkStmt->close();

        $stmt = $conn->prepare("DELETE FROM medications WHERE medication_id = ?");
        $stmt->bind_param("i", $medicationId);

        if ($stmt->execute() && $stmt->affected_rows > 0) {
            http_response_code(200);
            echo json_encode(["status" => true, "message" => "Medication deleted successfully", "data" => []]);
        } else {
            http_response_code(500);
            echo json_encode(["status" => false, "message" => "Failed to delete medication", "data" => []]);
        }

        $stmt->close();
    } else {
        http_response_code(200);
        echo json_encode(["status" => false, "message" => "Medication ID is required", "data" => []]);
    }

} else {
    http_response_code(200);
    echo json_encode(["status" => false, "message" => "Invalid request method", "data" => []]);
}

$conn->close();
?>
