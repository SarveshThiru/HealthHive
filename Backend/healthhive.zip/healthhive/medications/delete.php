<?php
header("Content-Type: application/json");
include '../db.php'; // Include database connection

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate required fields
    if (!empty($_POST['medication_id'])) {
        // Get the medication ID from form-data
        $medicationId = intval($_POST['medication_id']);

        // Prepare SQL statement
        $stmt = $conn->prepare("DELETE FROM medications WHERE medication_id = ?");
        $stmt->bind_param("i", $medicationId);

        // Execute the query
        if ($stmt->execute()) {
            echo json_encode(["message" => "Medication deleted successfully"]);
        } else {
            echo json_encode(["error" => "Failed to delete medication"]);
        }

        $stmt->close();
    } else {
        echo json_encode(["error" => "Medication ID is required"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method. Use POST to delete medication."]);
}

$conn->close();
?>
