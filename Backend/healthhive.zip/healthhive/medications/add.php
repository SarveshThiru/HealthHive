<?php
header("Content-Type: application/json");
include '../db.php'; // Include database connection

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate required fields
    if (!empty($_POST['user_id']) && !empty($_POST['name']) && !empty($_POST['dosage']) && 
        !empty($_POST['frequency']) && !empty($_POST['start_date'])) {
        
        // Get form data
        $userId = intval($_POST['user_id']);
        $name = $_POST['name'];
        $dosage = $_POST['dosage'];
        $frequency = $_POST['frequency'];
        $startDate = $_POST['start_date'];
        $endDate = $_POST['end_date'] ?? null;
        $doctorName = $_POST['doctor_name'] ?? null;
        $doctorNotes = $_POST['doctor_notes'] ?? null;
        $sideEffects = $_POST['side_effects'] ?? null;
        $expiryDate = $_POST['expiry_date'] ?? null;
        $purchaseDate = $_POST['purchase_date'] ?? null;

        // Prepare SQL statement
        $stmt = $conn->prepare("INSERT INTO medications 
            (user_id, name, dosage, frequency, start_date, end_date, doctor_name, doctor_notes, side_effects, expiry_date, purchase_date) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->bind_param("issssssssss", $userId, $name, $dosage, $frequency, $startDate, $endDate, $doctorName, $doctorNotes, $sideEffects, $expiryDate, $purchaseDate);
        
        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode(["message" => "Medication added successfully"]);
        } else {
            echo json_encode(["error" => "Failed to add medication"]);
        }

        $stmt->close();
    } else {
        echo json_encode(["error" => "Missing required fields"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method. Use POST to add medication."]);
}

$conn->close();
?>
