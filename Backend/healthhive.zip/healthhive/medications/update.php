<?php
header("Content-Type: application/json");
include '../db.php'; // Include database connection

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate if medication_id is provided
    if (!empty($_POST['medication_id'])) {
        // Get the medication ID
        $medicationId = intval($_POST['medication_id']);

        // Get values from form-data (set defaults for optional fields)
        $name = $_POST['name'] ?? null;
        $dosage = $_POST['dosage'] ?? null;
        $frequency = $_POST['frequency'] ?? null;
        $startDate = $_POST['start_date'] ?? null;
        $endDate = $_POST['end_date'] ?? null;
        $doctorName = $_POST['doctor_name'] ?? null;
        $doctorNotes = $_POST['doctor_notes'] ?? null;
        $sideEffects = $_POST['side_effects'] ?? null;
        $expiryDate = $_POST['expiry_date'] ?? null;
        $purchaseDate = $_POST['purchase_date'] ?? null;

        // Prepare SQL statement
        $sql = "UPDATE medications 
                SET name=?, dosage=?, frequency=?, start_date=?, end_date=?, doctor_name=?, doctor_notes=?, side_effects=?, expiry_date=?, purchase_date=? 
                WHERE medication_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssssi", $name, $dosage, $frequency, $startDate, $endDate, $doctorName, $doctorNotes, $sideEffects, $expiryDate, $purchaseDate, $medicationId);

        // Execute the query
        if ($stmt->execute()) {
            echo json_encode(["message" => "Medication updated successfully"]);
        } else {
            echo json_encode(["error" => "Failed to update medication"]);
        }

        $stmt->close();
    } else {
        echo json_encode(["error" => "Medication ID is required"]);
    }
} else {
    echo json_encode(["error" => "Invalid request method. Use POST to update medication."]);
}

$conn->close();
?>
