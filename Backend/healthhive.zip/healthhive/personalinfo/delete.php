<?php
include '../db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['user_id'])) {
    $user_id = $data['user_id'];

    // Delete personal info for the user
    $stmt = $conn->prepare("DELETE FROM personal_info WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    
    if ($stmt->execute()) {
        echo json_encode(["message" => "Personal info deleted successfully"]);
    } else {
        echo json_encode(["error" => "Failed to delete personal info"]);
    }
    
    $stmt->close();
}
?>
