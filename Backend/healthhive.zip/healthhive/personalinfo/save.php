<?php
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $user_id = $_POST['user_id'];
    $full_name = $_POST['full_name'];
    $mobile_number = $_POST['mobile_number'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $emergency_contact = $_POST['emergency_contact'];
    $address = $_POST['address']; // New Address Field

    // Check if user exists in the users table
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows == 0) {
        echo json_encode(["error" => "User does not exist"]);
        exit();
    }

    // Check if personal info exists for the user
    $stmt = $conn->prepare("SELECT id FROM personal_info WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        // Update existing record
        $stmt = $conn->prepare("UPDATE personal_info SET full_name=?, mobile_number=?, dob=?, email=?, emergency_contact=?, address=? WHERE user_id=?");
        $stmt->bind_param("ssssssi", $full_name, $mobile_number, $dob, $email, $emergency_contact, $address, $user_id);
    } else {
        // Insert new record
        $stmt = $conn->prepare("INSERT INTO personal_info (user_id, full_name, mobile_number, dob, email, emergency_contact, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssss", $user_id, $full_name, $mobile_number, $dob, $email, $emergency_contact, $address);
    }
    
    if ($stmt->execute()) {
        echo json_encode(["message" => "Personal info saved successfully"]);
    } else {
        echo json_encode(["error" => "Failed to save personal info"]);
    }

    $stmt->close();
}
?>
