<?php
header("Content-Type: application/json; charset=UTF-8");
include '../db.php';

$request_method = $_SERVER["REQUEST_METHOD"];

function response($status, $message, $data = []) {
    echo json_encode(["status" => $status, "message" => $message, "data" => $data]);
    exit();
}

if ($request_method === "POST") {
    if (!isset($_POST['user_id']) || !is_numeric($_POST['user_id']) || intval($_POST['user_id']) <= 0) {
        http_response_code(400);
        response(false, "Invalid or missing user_id");
    }

    $user_id = intval($_POST['user_id']);
    $full_name = filter_var(trim($_POST['full_name']), FILTER_SANITIZE_SPECIAL_CHARS);
    $mobile_number = filter_var(trim($_POST['mobile_number']), FILTER_SANITIZE_SPECIAL_CHARS);
    $dob = filter_var(trim($_POST['dob']), FILTER_SANITIZE_SPECIAL_CHARS);
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $emergency_contact = filter_var(trim($_POST['emergency_contact']), FILTER_SANITIZE_SPECIAL_CHARS);
    $address = filter_var(trim($_POST['address']), FILTER_SANITIZE_SPECIAL_CHARS);

    if (!$email) {
        http_response_code(400);
        response(false, "Invalid email format");
    }

    $stmt = $conn->prepare("SELECT user_id FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows == 0) {
        http_response_code(404);
        response(false, "User does not exist");
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT id FROM personal_info WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE personal_info SET full_name=?, mobile_number=?, dob=?, email=?, emergency_contact=?, address=? WHERE user_id=?");
        $stmt->bind_param("ssssssi", $full_name, $mobile_number, $dob, $email, $emergency_contact, $address, $user_id);
    } else {
        $stmt = $conn->prepare("INSERT INTO personal_info (user_id, full_name, mobile_number, dob, email, emergency_contact, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssss", $user_id, $full_name, $mobile_number, $dob, $email, $emergency_contact, $address);
    }

    if ($stmt->execute()) {
        http_response_code(200);
        response(true, "Personal info saved successfully");
    } else {
        http_response_code(500);
        error_log("DB Error: " . $stmt->error);
        response(false, "Failed to save personal info");
    }

    $stmt->close();
    $conn->close();
} 

elseif ($request_method === "GET") {
    if (!isset($_GET['user_id']) || !is_numeric($_GET['user_id']) || intval($_GET['user_id']) <= 0) {
        http_response_code(400);
        response(false, "Invalid or missing user_id");
    }

    $user_id = intval($_GET['user_id']);

    $stmt = $conn->prepare("SELECT full_name, mobile_number, dob, email, emergency_contact, address FROM personal_info WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        response(true, "User personal info retrieved successfully", $result->fetch_assoc());
    } else {
        http_response_code(404);
        response(false, "User personal info not found");
    }

    $stmt->close();
    $conn->close();
} 

elseif ($request_method === "DELETE") {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (!isset($data['user_id']) || !is_numeric($data['user_id']) || intval($data['user_id']) <= 0) {
        http_response_code(400);
        response(false, "Invalid or missing user_id");
    }

    $user_id = intval($data['user_id']);

    $stmt = $conn->prepare("SELECT id FROM personal_info WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows === 0) {
        http_response_code(404);
        response(false, "No personal info found for the given user_id");
    }
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM personal_info WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        http_response_code(200);
        response(true, "Personal info deleted successfully");
    } else {
        http_response_code(500);
        error_log("DB Error: " . $stmt->error);
        response(false, "Failed to delete personal info");
    }

    $stmt->close();
    $conn->close();
} 

else {
    http_response_code(405);
    response(false, "Invalid request method");
}