<?php
header("Content-Type: application/json; charset=UTF-8");
include '../db.php';

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    if (!isset($_GET['user_id']) || empty($_GET['user_id'])) {
        echo json_encode(["error" => "Missing user_id"]);
        exit();
    }

    $user_id = intval($_GET['user_id']); // Ensure user_id is an integer

    // Fetch personal info for the user
    $stmt = $conn->prepare("SELECT * FROM personal_info WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        echo json_encode($data);
    } else {
        echo json_encode(["error" => "User personal info not found"]);
    }

    $stmt->close();
    $conn->close();

    // Flush output to ensure it gets sent
    ob_flush();
    flush();
} else {
    echo json_encode(["error" => "Invalid request method"]);
}
?>
