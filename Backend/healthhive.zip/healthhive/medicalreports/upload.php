<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_FILES['file']) || !isset($_POST['user_id'])) {
        echo json_encode(["error" => "File and User ID are required"]);
        exit();
    }

    $user_id = $_POST['user_id'];
    $description = $_POST['description'] ?? '';
    $date = $_POST['date'] ?? date('Y-m-d');
    $doctor_name = $_POST['doctor_name'] ?? '';

    $upload_dir = "../uploads/";
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $file_name = time() . "_" . basename($_FILES["file"]["name"]);
    $file_path = $upload_dir . $file_name;

    if (move_uploaded_file($_FILES["file"]["tmp_name"], $file_path)) {
        $stmt = $conn->prepare("INSERT INTO medical_reports (user_id, description, date, doctor_name, file_url) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $user_id, $description, $date, $doctor_name, $file_name);
        
        if ($stmt->execute()) {
            echo json_encode(["message" => "Report uploaded successfully", "file_url" => "uploads/" . $file_name]);
        } else {
            echo json_encode(["error" => "Database insert failed"]);
        }
        
        $stmt->close();
    } else {
        echo json_encode(["error" => "File upload failed"]);
    }
}
?>
