<?php
include '../db.php';
header("Content-Type: application/json");

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    if (isset($_FILES['file'])) {
        // **UPLOAD REPORT**
        if (!isset($_POST['user_id'])) {
            echo json_encode(["status" => false, "message" => "User ID is required", "data" => []]);
            exit();
        }

        $user_id = intval($_POST['user_id']);
        $description = trim($_POST['description'] ?? '');
        $date = $_POST['date'] ?? date('Y-m-d');
        $doctor_name = trim($_POST['doctor_name'] ?? '');

        // Validate file type (PDF, JPG, PNG)
        $allowed_types = ['application/pdf', 'image/jpeg', 'image/png'];
        $file_mime = mime_content_type($_FILES["file"]["tmp_name"]);

        if (!in_array($file_mime, $allowed_types)) {
            echo json_encode(["status" => false, "message" => "Invalid file type. Only PDF, JPG, and PNG are allowed.", "data" => []]);
            exit();
        }

        // Set upload directory
        $upload_dir = "../uploads/";
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Secure file name
        $file_ext = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);
        $file_name = time() . "_" . bin2hex(random_bytes(8)) . "." . $file_ext;
        $file_path = $upload_dir . $file_name;

        if (move_uploaded_file($_FILES["file"]["tmp_name"], $file_path)) {
            $stmt = $conn->prepare("INSERT INTO medical_reports (user_id, description, date, doctor_name, file_url) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("issss", $user_id, $description, $date, $doctor_name, $file_name);

            if ($stmt->execute()) {
                echo json_encode(["status" => true, "message" => "Report uploaded successfully", "data" => ["file_url" => "uploads/" . $file_name]]);
            } else {
                echo json_encode(["status" => false, "message" => "Database insert failed", "data" => []]);
            }

            $stmt->close();
        } else {
            echo json_encode(["status" => false, "message" => "File upload failed", "data" => []]);
        }
    } elseif (isset($_POST['report_id'])) {
        // **DELETE REPORT**
        $report_id = intval($_POST['report_id']);

        $stmt = $conn->prepare("SELECT file_url FROM medical_reports WHERE report_id = ?");
        $stmt->bind_param("i", $report_id);
        $stmt->execute();
        $stmt->bind_result($file_url);
        $stmt->fetch();
        $stmt->close();

        if (!$file_url) {
            echo json_encode(["status" => false, "message" => "Report not found", "data" => []]);
            exit();
        }

        $stmt = $conn->prepare("DELETE FROM medical_reports WHERE report_id = ?");
        $stmt->bind_param("i", $report_id);

        if ($stmt->execute()) {
            $file_path = "../uploads/" . $file_url;
            if (file_exists($file_path)) {
                unlink($file_path);
            }

            echo json_encode(["status" => true, "message" => "Report deleted successfully", "data" => []]);
        } else {
            echo json_encode(["status" => false, "message" => "Failed to delete report", "data" => []]);
        }

        $stmt->close();
    } else {
        echo json_encode(["status" => false, "message" => "Invalid request", "data" => []]);
    }
} elseif ($method === 'GET' && isset($_GET['user_id'])) {
    // **FETCH REPORTS**
    $user_id = intval($_GET['user_id']);

    $stmt = $conn->prepare("SELECT report_id, description, date, doctor_name, file_url FROM medical_reports WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $reports = [];

        while ($row = $result->fetch_assoc()) {
            $reports[] = $row;
        }

        echo json_encode(["status" => true, "message" => "Reports fetched successfully", "data" => $reports]);
    } else {
        echo json_encode(["status" => false, "message" => "Database error", "data" => []]);
    }

    $stmt->close();
} else {
    echo json_encode(["status" => false, "message" => "Invalid request", "data" => []]);
}
?>
