<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['report_id'])) {
        echo json_encode(["error" => "Report ID is required"]);
        exit();
    }

    $report_id = $_POST['report_id'];

    // Get file path before deleting
    $stmt = $conn->prepare("SELECT file_url FROM medical_reports WHERE report_id = ?");
    $stmt->bind_param("i", $report_id);
    $stmt->execute();
    $stmt->bind_result($file_url);
    $stmt->fetch();
    $stmt->close();

    if (!$file_url) {
        echo json_encode(["error" => "Report not found"]);
        exit();
    }

    // Delete from database
    $stmt = $conn->prepare("DELETE FROM medical_reports WHERE report_id = ?");
    $stmt->bind_param("i", $report_id);
    if ($stmt->execute()) {
        unlink("../uploads/" . $file_url);
        echo json_encode(["message" => "Report deleted successfully"]);
    } else {
        echo json_encode(["error" => "Failed to delete report"]);
    }
    $stmt->close();
}
?>
