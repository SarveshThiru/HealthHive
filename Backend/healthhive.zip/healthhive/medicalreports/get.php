<?php
include '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!isset($_GET['user_id'])) {
        echo json_encode(["error" => "User ID is required"]);
        exit();
    }

    $user_id = $_GET['user_id'];
    $stmt = $conn->prepare("SELECT * FROM medical_reports WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $reports = [];
    while ($row = $result->fetch_assoc()) {
        $reports[] = $row;
    }

    echo json_encode($reports);
}
?>
